# App name

[brief description of the app]
Support app
Displays the NASA image of the day and you can change the image based on the day you click on the calendar.
You can click on the image to expand for modal view.

### The following information is displayed:

* info1
* info2
* info3

Please submit bug reports to [Insert Link](). Pull requests are welcome.

### Screenshot(s):
[put your screenshots down here.]
https://github.com/sushmamangalapally/support-app-zen/ScreenShotZen1.png
https://github.com/sushmamangalapally/support-app-zen/ScreenShotZen2.png