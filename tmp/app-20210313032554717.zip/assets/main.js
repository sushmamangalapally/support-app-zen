$(function() {
  var client = ZAFClient.init();
  client.get('ticket.requester.id').then(function(data) {
      console.log('test')
      const user_id = data['ticket.requester.id'];
      requestUserInfo(client, user_id);

  console.log(data['ticket.requester.id']); // something like 29043265
});


  client.invoke('resize', { width: '100%', height: '120px' });
//   showInfo();
//   showError();
});

function requestUserInfo(client, id) {
  var settings = {
    url: '/api/v2/users/' + id + '.json',
    type:'GET',
    dataType: 'json',
  };

  client.request(settings).then(
    function(data) {
        showInfo(data)
      console.log(data);
    },
    function(response) {
        showError(response);
    //   console.error(response);
    }
  );

}

function formatDate(date) {
    let cdate = new Date(date);
    let options = {
        year: "numeric",
        month: "short",
        day: "numeric"
    }
    date = cdate.toLocaleDateString("en-us", options);
    return date;
}

function showInfo(data) {
  var requester_data = {
    'name': data.user.name,
    'tags': data.user.tags,
    'created_at': formatDate(data.user.created_at),
    'last_login_at': data.user.last_login_at ? formatDate(data.user.last_login_at) : null
  };

  var source = $("#requester-template").html();
  var template = Handlebars.compile(source);
  var html = template(requester_data);
  $("#content").html(html);
}

function showError(response) {
  var error_data = {
    'status': response.status,
    'statusText': response.statusText
  };
  var source = $("#error-template").html();
  var template = Handlebars.compile(source);
  var html = template(error_data);
  $("#content").html(html);
}
